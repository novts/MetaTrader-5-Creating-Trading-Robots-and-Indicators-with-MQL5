from datetime import datetime
import MetaTrader5 as mt5
import pandas as pd

mt5.initialize()

def open_position(pair, order_type, size, tp = None, sl = None):
    symbol_info = mt5.symbol_info(pair)
    if symbol_info is None:
        print(pair, "not found")
        mt5.shutdown()
        quit()
    point = symbol_info.point
    
    if(order_type == "BUY"):
        order = mt5.ORDER_TYPE_BUY
        price = mt5.symbol_info_tick(pair).ask
        if(sl):
            sl = price - (sl * point)
        if(tp):
            tp = price + (tp * point)
            
    if(order_type == "SELL"):
        order = mt5.ORDER_TYPE_SELL
        price = mt5.symbol_info_tick(pair).bid
        if(sl):
            sl = price + (sl * point)
        if(tp):
            tp = price - (tp * point)

    request = {
        "action": mt5.TRADE_ACTION_DEAL,
        "symbol": pair,
        "volume": float(size),
        "type": order,
        "price": price,
        "sl": sl,
        "tp": tp,
        "magic": 234000,
        "comment": "",
        "type_time": mt5.ORDER_TIME_GTC,
        "type_filling": mt5.ORDER_FILLING_IOC,
    }

    result = mt5.order_send(request)

    if result.retcode != mt5.TRADE_RETCODE_DONE:
        print("Failed to send order :(")
    else:
        print ("Order successfully placed!")
        
def close_position(pair):
    res = mt5.positions_get(symbol=pair)  
    
    if(res is not None and len(res)>0):
        open_positions=pd.DataFrame(list(res),columns=res[0]._asdict().keys())
    else:
        mt5.shutdown()
        quit()
     
    order_type  = open_positions['type'][0]
    size = open_positions['volume'][0]

    if(order_type == mt5.ORDER_TYPE_BUY):
        order_type = mt5.ORDER_TYPE_SELL
        price = mt5.symbol_info_tick(pair).bid
    else:
        order_type = mt5.ORDER_TYPE_BUY
        price = mt5.symbol_info_tick(symbol).ask
	
    request = {
        "action": mt5.TRADE_ACTION_DEAL,
        "symbol": pair,
        "volume": float(size),
        "type": order_type,
        "price": price,
        "magic": 234000,
        "comment": "Close Trade",
        "type_time": mt5.ORDER_TIME_GTC,
        "type_filling": mt5.ORDER_FILLING_IOC,
    }

    result = mt5.order_send(request)

    if result.retcode != mt5.TRADE_RETCODE_DONE:
        print("Failed to send order :(")
    else:
        print ("Order successfully placed!")
   

#open_position("EURUSD", "BUY", 0.1, 500, 500)
#open_position("EURUSD", "BUY", 0.1, 100, 100)

close_position("EURUSD")

mt5.shutdown()

