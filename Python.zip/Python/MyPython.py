from datetime import datetime
import MetaTrader5 as mt5
import matplotlib.pyplot as plt
import pandas as pd
from pandas.plotting import register_matplotlib_converters
register_matplotlib_converters()
import pytz

if not mt5.initialize():
    print("initialize() failed, error code =", mt5.last_error())
    quit()

# request 100 bars on EURUSD D1 from the current day
rates_from_pos = mt5.copy_rates_from_pos("EURUSD", mt5.TIMEFRAME_D1, 0, 100)

# set timezone to UTC
timezone = pytz.timezone("Etc/UTC")
# create a datetime object in the UTC timezone so that the local timezone offset is not applied
utc_from = datetime(2022, 10, 1, tzinfo=timezone)
# we will get 10 bars with EURUSD H4 starting from 10/01/2022 in the UTC timezone
rates_from = mt5.copy_rates_from("EURUSD", mt5.TIMEFRAME_H4, utc_from, 10)
# request 1000 ticks for EURUSD from 10/01/2022 in the UTC time zone
ticks_from = mt5.copy_ticks_from("EURUSD", utc_from, 1000, mt5.COPY_TICKS_ALL)

mt5.shutdown()

# create a DataFrame from the received data
rates_frame_pos = pd.DataFrame(rates_from_pos)
# convert time in seconds to datetime format
rates_frame_pos['time']=pd.to_datetime(rates_frame_pos['time'], unit='s')

# create a DataFrame from the received data
rates_frame = pd.DataFrame(rates_from)
# convert time in seconds to datetime format
rates_frame['time']=pd.to_datetime(rates_frame['time'], unit='s')
# create a DataFrame from the received data
ticks_frame = pd.DataFrame(ticks_from)
# convert time in seconds to datetime format
ticks_frame['time']=pd.to_datetime(ticks_frame['time'], unit='s') 

# output the data
print('EURUSD(', len(rates_frame_pos), ')')
print(rates_frame_pos) 
print('EURUSD(', len(rates_frame), ')')
print(rates_frame) 
print('EURUSD(', len(ticks_frame), ')')
print(ticks_frame) 

# draw ticks on the chart
plt.plot(ticks_frame['time'], ticks_frame['ask'], 'r-', label='ask')
plt.plot(ticks_frame['time'], ticks_frame['bid'], 'b-', label='bid') 
# display the legends 
plt.legend(loc='upper left') 
# add a title 
plt.title('EURAUD ticks') 
# show graph
plt.show()


