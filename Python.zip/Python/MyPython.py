from datetime import datetime
import MetaTrader5 as mt5
import matplotlib.pyplot as plt
import pandas as pd
from pandas.plotting import register_matplotlib_converters
register_matplotlib_converters()
import pytz

if not mt5.initialize():
    print("initialize() failed, error code =", mt5.last_error())
    quit()

# запросим 100 баров на EURUSD D1 c текущего дня
rates_from_pos = mt5.copy_rates_from_pos("EURUSD", mt5.TIMEFRAME_D1, 0, 100)

# установим таймзону в UTC
timezone = pytz.timezone("Etc/UTC")
# создадим объект datetime в таймзоне UTC, чтобы не применялось смещение локальной таймзоны
utc_from = datetime(2022, 10, 1, tzinfo=timezone)
# получим 10 баров с EURUSD H4 начиная с 01.10.2022 в таймзоне UTC
rates_from = mt5.copy_rates_from("EURUSD", mt5.TIMEFRAME_H4, utc_from, 10)
# запросим 1000 тиков по EURUSD с 01.10.2022 в таймзоне UTC
ticks_from = mt5.copy_ticks_from("EURUSD", utc_from, 1000, mt5.COPY_TICKS_ALL)

mt5.shutdown()

# создадим из полученных данных DataFrame
rates_frame_pos = pd.DataFrame(rates_from_pos)
# сконвертируем время в виде секунд в формат datetime
rates_frame_pos['time']=pd.to_datetime(rates_frame_pos['time'], unit='s')

# создадим из полученных данных DataFrame
rates_frame = pd.DataFrame(rates_from)
# сконвертируем время в виде секунд в формат datetime
rates_frame['time']=pd.to_datetime(rates_frame['time'], unit='s')

# создадим из полученных данных DataFrame
ticks_frame = pd.DataFrame(ticks_from)
# сконвертируем время в виде секунд в формат datetime
ticks_frame['time']=pd.to_datetime(ticks_frame['time'], unit='s')
 
# выведем данные
print('EURUSD(', len(rates_frame_pos), ')')
print(rates_frame_pos) 

print('EURUSD(', len(rates_frame), ')')
print(rates_frame) 
print('EURUSD(', len(ticks_frame), ')')
print(ticks_frame) 
# сделаем отрисовку тиков на графике
plt.plot(ticks_frame['time'], ticks_frame['ask'], 'r-', label='ask')
plt.plot(ticks_frame['time'], ticks_frame['bid'], 'b-', label='bid') 
# выведем легенды 
plt.legend(loc='upper left') 
# добавим заголовок 
plt.title('EURAUD ticks') 
# покажем график
plt.show()


