from datetime import datetime
import MetaTrader5 as mt5
import pandas as pd
from sklearn.preprocessing import MinMaxScaler
from tensorflow import keras
import numpy

def LoadMt5(symbol):
    
    if not mt5.initialize():
        print("initialize() failed, error code =", mt5.last_error())
        quit()
        
    now = datetime.utcnow()
    # запросить 120 таймфреймов D1 как данные OHLC
    ticks = mt5.copy_rates_from(symbol, mt5.TIMEFRAME_D1, now, 120)
    #print("Ticks received:", len(ticks))
    
    mt5.shutdown()
    
    # создадим из полученных данных DataFrame
    df = pd.DataFrame(ticks)    
    # сконвертируем время в виде секунд в формат datetime
    df['time'] = pd.to_datetime(df['time'], unit='s')
    
    return df 

df=LoadMt5("EURUSD")

# Keras models accept three types of inputs:NumPy arrays, TensorFlow Dataset objects, Python generators
# convert a Pandas series to a NumPy array 
data_close=df["close"].values
data_open=df["open"].values

# Once data is in the form of NumpPy arrays, it is time to preprocess the data.
# Rescaling the data to small values. In general, values to a neural network should be close to zero - in the [0, 1] range.
# StandardScaler follows Standard Normal Distribution (SND). MinMaxScaler scales all the data features in the range [0, 1] or else in the range [-1, 1] if there are negative values in the dataset.
scaler = MinMaxScaler()

# scikit-learn transformers expect data in two-dimensional form. 
data_close=data_close.reshape(-1,1)
data_open=data_open.reshape(-1,1)
# -1 is the unknown dimension of the array. 
# we want a COLUMN vector (many/one/unknown samples, 1 feature)

# scale data matrix to the [0, 1] range
data_close = scaler.fit_transform(data_close)
data_open = scaler.fit_transform(data_open)

# reshape the data back
data_close=data_close.reshape(-1)
data_open=data_open.reshape(-1)

# split the training data and test data
def train_test_split(data, factor):
    train_size = int(len(data) * factor)
    return data[0:train_size], data[train_size:len(data)]

# from training data create patterns for predictions
def patterns_split(train_data, step):
    X, y = list(), list()
    for i in range(len(train_data)):
        # find the end of this pattern
        end = i + step
        # check if we are beyond the data length
        if end > len(train_data)-1:
            break
        # gather input and output parts of the pattern
        X_part, y_part = train_data[i:end], train_data[end]
        X.append(X_part)
        y.append(y_part)
    return numpy.array(X), numpy.array(y)

train_data_close, test_data_close = train_test_split(data_close, 0.7)
train_data_open, test_data_open = train_test_split(data_open, 0.7)
X_train_close, y_train_close = patterns_split(train_data_close, 10)
X_test_close, y_test_close = patterns_split(test_data_close, 10)
X_train_open, y_train_open = patterns_split(train_data_open, 10)
X_test_open, y_test_open = patterns_split(test_data_open, 10)

def print_data(X,y):
    for i in range(len(X)):
        print(X[i], y[i])       

# Keras inputs: A 3D tensor with shape [batch, timesteps, feature]
# For a 2D array, the shape would be (n,m) where n is the number of rows and m is the number of columns in your array.
X_train_close=X_train_close.reshape(X_train_close.shape[0],X_train_close.shape[1], 1)
X_test_close=X_test_close.reshape(X_test_close.shape[0],X_test_close.shape[1], 1)
X_train_open=X_train_open.reshape(X_train_open.shape[0],X_train_open.shape[1], 1)
X_test_open=X_test_open.reshape(X_test_open.shape[0],X_test_open.shape[1], 1)

# Keras mask: Binary tensor of shape [batch, timesteps]
y_train_close=y_train_close.reshape(y_train_close.shape[0], 1)
y_test_close=y_test_close.reshape(y_test_close.shape[0], 1)
y_train_open=y_train_open.reshape(y_train_open.shape[0], 1)
y_test_open=y_test_open.reshape(y_test_open.shape[0], 1)

from keras.models import Sequential
from keras.layers import Dense
from keras.layers import LSTM

# create and fit the LSTM network
# Initialising the RNN
model_close = Sequential()
model_open = Sequential()

TimeSteps_close=X_train_close.shape[1]
TotalFeatures_close=X_train_close.shape[2]
TimeSteps_open=X_train_open.shape[1]
TotalFeatures_open=X_train_open.shape[2]
 
# Adding the input hidden LSTM layer
# return_sequences = True, 
#means the output of every time step to be shared with hidden next layer
num_units_1=10
num_units_2=10
actv = 'tanh'

model_close.add(LSTM(units = num_units_1, activation = actv,
input_shape = (TimeSteps_close, TotalFeatures_close), return_sequences=True))
model_open.add(LSTM(units = num_units_1, activation = actv,
input_shape = (TimeSteps_open, TotalFeatures_open), return_sequences=True))
 
# Adding the hidden LSTM layer
model_close.add(LSTM(units = num_units_2, activation = actv,
input_shape = (TimeSteps_close, TotalFeatures_close), return_sequences=True))
model_open.add(LSTM(units = num_units_2, activation = actv,
input_shape = (TimeSteps_open, TotalFeatures_open), return_sequences=True))
 
# Adding the hidden LSTM layer
model_close.add(LSTM(units = num_units_2, activation = actv,
return_sequences=False )) 
model_open.add(LSTM(units = num_units_2, activation = actv,
return_sequences=False )) 
 
# Adding the output layer
model_close.add(Dense(units = 1))
model_open.add(Dense(units = 1))
 
# Compiling the RNN
model_close.compile(optimizer = 'adam', loss = 'mean_squared_error')
model_open.compile(optimizer = 'adam', loss = 'mean_squared_error')
 
# Fitting the RNN to the Training set
model_close.fit(X_train_close, y_train_close, batch_size = 5, epochs = 100)
model_open.fit(X_train_open, y_train_open, batch_size = 5, epochs = 100)
 
predicted_Price_close = model_close.predict(X_test_close)
predicted_Price_close = scaler.inverse_transform(predicted_Price_close)
predicted_Price_open = model_open.predict(X_test_open)
predicted_Price_open = scaler.inverse_transform(predicted_Price_open)
 
# Getting the original price values for testing data
orig_close=y_test_close
orig_close=scaler.inverse_transform(y_test_close)
orig_open=y_test_open
orig_open=scaler.inverse_transform(y_test_open)
 
# Accuracy of the predictions
print('Accuracy Close:', 100 - (100*(abs(orig_close-predicted_Price_close)/orig_close)).mean())
print('Accuracy Open:', 100 - (100*(abs(orig_open-predicted_Price_open)/orig_open)).mean())

model_close.save(r'C:\Users\user\Desktop\model_train_EURUSD_close.h5')
model_open.save(r'C:\Users\user\Desktop\model_train_EURUSD_open.h5')
 
# Visualising the results
import matplotlib.pyplot as plt

def plot(predicted_Price, orig, X_test):
     plt.plot(predicted_Price, color = 'blue', label = 'Predicted Price')
     plt.plot(orig, color = 'lightblue', label = 'Original Price')
 
     plt.title('Price Predictions')
     plt.xlabel('Trading Date')
     plt.xticks(range(X_test.shape[0]), df.tail(X_test.shape[0])['time'])
     plt.ylabel('Price')
 
     plt.legend()
     fig=plt.gcf()
     fig.set_figwidth(20)
     fig.set_figheight(6)
     plt.show()
     
plot(predicted_Price_close, orig_close, X_test_close)
plot(predicted_Price_open, orig_open, X_test_open)