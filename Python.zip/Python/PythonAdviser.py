from datetime import datetime, timezone
import MetaTrader5 as mt5
import pandas as pd
from sklearn.preprocessing import MinMaxScaler
from tensorflow import keras
import numpy

def LoadMt5(symbol):
    
    if not mt5.initialize():
        print("initialize() failed, error code =", mt5.last_error())
        quit()
        
    now = datetime.utcnow()
    # запросить 10 таймфреймов D1 как данные OHLC
    ticks = mt5.copy_rates_from(symbol, mt5.TIMEFRAME_D1, now, 10)
    #print("Ticks received:", len(ticks))
    
    mt5.shutdown()
    
    # создадим из полученных данных DataFrame
    df = pd.DataFrame(ticks)    
    # сконвертируем время в виде секунд в формат datetime
    df['time'] = pd.to_datetime(df['time'], unit='s')
    
    return df 

df=LoadMt5("EURUSD")
data_close=df["close"].values
data_open=df["open"].values

scaler = MinMaxScaler()
data_close=data_close.reshape(-1,1)
data_open=data_open.reshape(-1,1)
data_close = scaler.fit_transform(data_close)
data_open = scaler.fit_transform(data_open)
data_close=data_close.reshape(-1)
data_open=data_open.reshape(-1)

# from data create patterns for predictions
def patterns(data):
    X = list()
    end = len(data)
    X_part = data[:end]
    X.append(X_part)
    return numpy.array(X)

X_close = patterns(data_close)
X_open = patterns(data_open)

X_close=X_close.reshape(X_close.shape[0],X_close.shape[1], 1)
X_open=X_open.reshape(X_open.shape[0],X_open.shape[1], 1)

model_close = keras.models.load_model(r'C:\Users\user\Desktop\model_train_EURUSD_close')
model_open = keras.models.load_model(r'C:\Users\user\Desktop\model_train_EURUSD_open')

predicted_Price_close = model_close.predict(X_close)
predicted_Price_close = scaler.inverse_transform(predicted_Price_close)
predicted_Price_open = model_open.predict(X_open)
predicted_Price_open = scaler.inverse_transform(predicted_Price_open)

print("predicted_Price_close ", predicted_Price_close)
print("predicted_Price_open ", predicted_Price_open)

def get_signal(predicted_Price_close, predicted_Price_open):
    if predicted_Price_close > predicted_Price_open:
        signal = "Buy"
    else:
       signal = "Sell"
    return signal 
        
signal = get_signal(predicted_Price_close, predicted_Price_open)

mt5.initialize()
def open_position(pair, order_type, size, tp = None, sl = None):
    symbol_info = mt5.symbol_info(pair)
    if symbol_info is None:
        print(pair, "not found")
        mt5.shutdown()
        quit()
    point = symbol_info.point    
    if(order_type == "BUY"):
        order = mt5.ORDER_TYPE_BUY
        price = mt5.symbol_info_tick(pair).ask
        if(sl):
            sl = price - (sl * point)
        if(tp):
            tp = price + (tp * point)            
    if(order_type == "SELL"):
        order = mt5.ORDER_TYPE_SELL
        price = mt5.symbol_info_tick(pair).bid
        if(sl):
            sl = price + (sl * point)
        if(tp):
            tp = price - (tp * point)

    request = {
        "action": mt5.TRADE_ACTION_DEAL,
        "symbol": pair,
        "volume": float(size),
        "type": order,
        "price": price,
        "sl": sl,
        "tp": tp,
        "magic": 234000,
        "comment": "",
        "type_time": mt5.ORDER_TIME_GTC,
        "type_filling": mt5.ORDER_FILLING_IOC,
    }

    result = mt5.order_send(request)

    if result.retcode != mt5.TRADE_RETCODE_DONE:
        print("Failed to send order :(")
    else:
        print ("Order successfully placed!")
        
def close_position(pair):
    res = mt5.positions_get(symbol=pair)  
    
    if(res is not None and len(res)>0):
        open_positions=pd.DataFrame(list(res),columns=res[0]._asdict().keys())
    else:
        mt5.shutdown()
        quit()
     
    order_type  = open_positions['type'][0]
    size = open_positions['volume'][0]

    if(order_type == mt5.ORDER_TYPE_BUY):
        order_type = mt5.ORDER_TYPE_SELL
        price = mt5.symbol_info_tick(pair).bid
    else:
        order_type = mt5.ORDER_TYPE_BUY
        price = mt5.symbol_info_tick(symbol).ask
	
    request = {
        "action": mt5.TRADE_ACTION_DEAL,
        "symbol": pair,
        "volume": float(size),
        "type": order_type,
        "price": price,
        "magic": 234000,
        "comment": "Close Trade",
        "type_time": mt5.ORDER_TIME_GTC,
        "type_filling": mt5.ORDER_FILLING_IOC,
    }

    result = mt5.order_send(request)

    if result.retcode != mt5.TRADE_RETCODE_DONE:
        print("Failed to send order :(")
    else:
        print ("Order successfully placed!")


while True:
    print(signal)
    now = datetime.now(tz=timezone.utc)
    #print(now)
    time = now.strftime("%H:%M:%S")
    #print(time)
    if time == "21:00:00" and signal == "Buy":
        open_position("EURUSD", "BUY", 0.1, 1000, 1000)
        print("BUY")
        break
    if time == "21:00:00" and signal == "Sell":
        open_position("EURUSD", "SELL", 0.1, 1000, 1000)
        print("SELL")
        break   
      
mt5.shutdown()
