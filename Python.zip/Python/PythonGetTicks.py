from datetime import datetime
import MetaTrader5 as mt5
import pandas as pd
import matplotlib.pyplot as plt

def LoadMt5(symbol):
    
    if not mt5.initialize():
        print("initialize() failed, error code =", mt5.last_error())
        quit()
        
    now = datetime.utcnow()

    # запросить 120 таймфреймов D1 как данные OHLC
    ticks = mt5.copy_rates_from(symbol, mt5.TIMEFRAME_D1, now, 120)
    #print("Ticks received:", len(ticks))
    
    mt5.shutdown()
    
    # создадим из полученных данных DataFrame
    df = pd.DataFrame(ticks)
    
    # сконвертируем время в виде секунд в формат datetime
    df['time'] = pd.to_datetime(df['time'], unit='s')
    df["high"] = df["high"].astype(float)
    df["low"] = df["low"].astype(float)
    df["close"] = df["close"].astype(float)

    return df

#print(LoadMt5("EURUSD"))

df=LoadMt5("EURUSD")
plt.plot(df['time'], (df['low']+df['high'])/2.0)
plt.xlabel('Date',fontsize=18)
plt.ylabel('Mid Price',fontsize=18)
plt.show()